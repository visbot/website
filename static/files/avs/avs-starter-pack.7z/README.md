# AVS Starter Pack

## Table of Contents

- `vis_avsmod.dll` (AVS v2.81d)
- `avs/AddBorder.ape`
- `avs/buffer.ape`
- `avs/channelshift.ape`
- `avs/colormap.ape`
- `avs/colorreduction.ape`
- `avs/convolution.ape`
- `avs/delay.ape`
- `avs/eeltrans.ape`
- `avs/FramerateLimiter.ape`
- `avs/fyrewurx.ape`
- `avs/globmgr.ape`
- `avs/multifilter.ape`
- `avs/multiplier.ape`
- `avs/normalise.ape`
- `avs/picture2.ape`
- `avs/texer.ape`
- `avs/texer2.ape`
- `avs/triangle.ape`
- `avs/VfxAviPlayer.ape`
- [Texer Resources](https://www.deviantart.com/tuggummi/art/Texer-Resources-3326598)
- [Texer Resources Extension Pack](https://www.deviantart.com/yathosho/art/Texer-Resources-Extension-Pack-210790887)
- [Mega Texer Pack](https://www.deviantart.com/yathosho/art/Mega-Texer-Pack-192409713)

# Installation

In most cases, you will have to extract `Plugins` folder from the archive to your default Winamp installation path (e.g. `%PROGRAMFILES(X86)%\Winamp`). If you have changed the default location for visualizations plugins (`VisDir`), that's where you have to extract the files inside the `Plugins` folder.
