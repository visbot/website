		ROCKY AVS II 
___________________________________________________________________________________________________________________________________________________________________________

After u have extracted the pack please take the effort to cut the earth font and place it in your control panel\font folder.
thank u


