Second Set of avS preSetS
ooKay, maybe i got a "little" carried away, because i have made pretty
big collection of 77 avs presets (is that big? i think it is too big)
So im worried that nobody has the intrest to suffle them all trough! =P
but you should do that! atleast i think they are pretty nice... well
compared to the avs society or some other 31337 group they suck
(i mean my avs presets suck) ,but they are all
pretty "light" so they work quite fast on slow machines as well...
well my machine has a Intel Pentium 233Mhz MMX CPU and i used the
windowed size 160x160 when i made most of these avs presets.
So if you like or dislike these send me some e-mail or write to my
GuestBook and tell me to stop making these things or to do more.
The name of this collection? Well i only used the very "basic" "blocks"
when i did these, meaning that i didn`t try to configure a unique
movement effect or superscope... well i guess you will understand when
you take a look at them closely.
Bye Bye for now.
- Tuggummi



Info About Author

Email:Juks@iobox.com
Homepage(redirect url): http://tuggummi.cjb.net
(full url: http://personal.inet.fi/cool/tuggummi)
Tuggummi: Jukka Keskinarkaus