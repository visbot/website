It`s my first set of avs presets.
I got interested in AVS after i downloaded the full version of
winamp v.2.666 (the halloween release 2000) so im a newbie in this area
and i attend to keep it that way because im more interested in making
skins than "playing" with avs, so this pack is made in the pure feeling
of fun and joy =) This does not mean that i do skins seriusly i just
want to handle skin making better than avs presets making, so maybe i
will make more avs presets some other time when i get an inspiration to
do so. Until then!
- Tuggummi



Info About Author

Email:Juks@iobox.com
Homepage(redirect url): http://tuggummi.cjb.net
(full url: http://personal.inet.fi/cool/tuggummi)
Tuggummi: Jukka Keskinarkaus