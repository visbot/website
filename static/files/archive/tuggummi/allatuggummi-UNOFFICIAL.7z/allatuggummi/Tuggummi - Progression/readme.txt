Humm...
Not much to say actually, just try to enjoy the presets and send me
feedback aBooT them.

...

And visit my webpage :)

...

And download my other presets and skins and enjoy them :)

- Tuggummi



Info About Author

Email:Juks@iobox.com
Homepage(redirect url): http://tuggummi.cjb.net
(full url: http://personal.inet.fi/cool/tuggummi)
Tuggummi: Jukka Keskinarkaus