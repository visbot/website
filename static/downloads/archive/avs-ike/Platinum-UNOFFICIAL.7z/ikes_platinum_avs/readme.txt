ok for all of you too simple for computers, heres what ya do...

extract this zip to plugins/avs/  in your winamp directory.. so unless you installed winamp somewhere special, extract it to C:\program file\winamp\plugins\avs\

now just open avs and load them







Some info about me:

name:       isaac delongchamp
email:      ike_in_the_post@hotmail.com
age:        15
location:   U.P. of Michigan.... way out there
AOL SN:     ikeinthepost



i'll probably have a new avs release before easter

untill then,
c-ya