Create a folder in your Program Files/Winamp/Plugins/avs folder, and
extract this zip file into the new folder.  These are my very best AVS
Presets, as rated by Deskmod.  enjoy...Indyrod

Indyrod@usa.com