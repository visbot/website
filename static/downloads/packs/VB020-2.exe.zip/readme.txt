this is an unfinished release of

whyeye.org
Heimcomputer II

it is yet uncertain, if there
will ever be a finished product.
most presets in the zip-files
have been created around july
2002. newer files suffered in
a hardware-crash.. twice! mixed
in a feeling of disappointment
is the fact, that new presets
don't get along with those *old*
presets in this pack and vice
versa. i'm more into making
heimcomputer iii, than ever
completing this pack. but maybe
i will. to complete this pack
i hade to do a *lot* of work
in textpad, since i have a lot
of ascii-animations in my mind.
heimcomputer iii will no longer
impress with even more insane
ascii animations. it will be an
attempt to look like early 16bit
console 3d optics.

blah..

jan
aka yathosho

freitag, 19 september 2003
20:24 CET